% Obliczenie �redniej g��boko�ci dla danego sondowania dla podanego zakresu kolumn (k�t�w)
pierwsza_dana = 1;
liczba_danych = 500;
kolumny = 41 : 80;  % Dla jakiego zakresu kolumn-wi�zek liczymy?
detrending = 1;  % Czy usuwamy trend - odemujemy aproksymowany liniowy przebieg 
%   dna (sk�adow� liniowo narastaj�c�) dla ka�dego sondowania?
%detrending = 0;
load dane_z
% �aduje si� vz - tablica 3D zawieraj�ca dane o g��boko�ci 
%   dna zmierzonej sonarem wielowi�zkowym, o rozmiarach: liczba
%   typ�w dna (= 4), liczba sondowa� (danych) (= 600), liczba wi�zek
%   w 1 sondowaniu (= 160).
[ltypowdna lswathow lbeamow] = size(vz);
clear var_sredniah
for itypdna = 1 : ltypowdna
  for idana = pierwsza_dana : pierwsza_dana - 1 + liczba_danych  % Zak�adamy, �e nie przekroczymy tu lswathow.
    % wybranie fragmentu obrazu (fragment 1 poziomej linii 1 obrazu-typu dna, 
    %   dla danego zakresu kolumn-wi�zek)
    fragm_obrazu_do_stat = reshape(vz(itypdna, idana, kolumny), 1, length(kolumny));
    z_l = length(fragm_obrazu_do_stat);
    % detrending
    if detrending
      a = polyfit(1 : z_l, fragm_obrazu_do_stat, 1);
      fragm_obrazu_do_stat = fragm_obrazu_do_stat - a(1) * (1:z_l) - a(2);
    end
    % obliczenie sredniej g��boko�ci dla danego typu dna i swath'u
    var_sredniah(itypdna, idana) = mean(fragm_obrazu_do_stat);
  end  % for idana
end  % for itypdna
