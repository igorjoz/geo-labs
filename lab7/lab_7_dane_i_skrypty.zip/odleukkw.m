function odl_kw = odleuk(x1, x2)
% Oblicza kwadrat odleg�o�ci euklidesowej pomi�dzy wektorami x1 i x2 w
%   przestrzeni length(x1)-wymiarowej (d�ugo�ci obu wektor�w musz� by�
%   takie same).
odl_kw = sum((x1 - x2) .* (x1 - x2));
