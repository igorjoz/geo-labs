% Wy�wietlenie "seabed (xy)z data" - siatki powierzchni dna morskiego
z_zakres = [-0.7 0.7];
%detrending = 0;  % Czy usuwamy trend - odemujemy aproksymowany liniowy przebieg 
%   dna (sk�adow� liniowo narastaj�c�) dla ka�dego sondowania?
detrending = 1;
swathsektor = 51:80;  % przyk�adowy fragment powierzchni dna
beamsektor = 41:80;
load dane_z  % Wczytuje si� zmienna vz - tablica 3D zawieraj�ca dane o g��boko�ci 
%   dna zmierzonej sonarem wielowi�zkowym, o rozmiarach: liczba
%   typ�w dna (= 4), liczba sondowa� (danych) (= 600), liczba wi�zek
%   w 1 sondowaniu (= 160).
[ltypowdna lswathow lbeamow] = size(vz);
% wy�wietlenie obraz�w
for itypdna = 1 : ltypowdna
  z = reshape(vz(itypdna, :, :), lswathow, lbeamow);
  % wybranie fragmentu obrazu
  z1 = z(swathsektor, beamsektor);
  [fragm_sizx fragm_sizy] = size(z1);
  % detrending
  if detrending
    for iswath = 1 : fragm_sizx
      a = polyfit(1 : fragm_sizy, z1(iswath, :), 1);
      z1(iswath, :) = z1(iswath, :) - a(1) * (1:fragm_sizy) - a(2);
    end
  end  
  figure
  colormap([zeros(256,1)  (1/256:1/256:1)' ones(256,1)]);  % generacja palety kolor�w
  mesh(beamsektor, swathsektor, z1)  % wy�wietlenie powierzchni dna w 3D
  set(gca, 'ZLim', z_zakres)  % ustawienie zakresu osi z (mo�na z tym poeksperymentowa�)
end  % itypdna = 1 : ltypowdna
